Required=50
Available=20
Buffer=30
Action=False

if Required<=Available:
    Action=True
elif Required<=Available+Buffer:
    Action=True

print(Action)

