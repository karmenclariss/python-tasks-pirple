def board(rows,columns):
    rows= int(rows)
    columns= int(columns)
    for row in range(rows):
        if row%2 == 0:
            for col in range(columns):
                if col%2 == 0:
                    if col == columns-1:
                        print(" ")
                    else:
                        print(" ", end="")
                else:
                    if col == columns-1:
                        print("|")
                    else:
                        print("|", end="")
        else:
            print("-"*columns)
    return True

print(board(11,11))

