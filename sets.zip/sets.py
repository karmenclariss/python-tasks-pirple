song = {
    "Title": "Wherever You Are",
    "Genre": "Pop",
    "Artist": "Kodaline",
    "Duration": "186",
    "Year_released": "2020",
    "Month_released": "January"
}

for key in song:
    print("{0:s}: \"{1:s}\"".format(key, song[key]))

