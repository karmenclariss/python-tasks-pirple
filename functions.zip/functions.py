def artist():
    output="Kodaline"
    print(output)
artist()

def genre():
    output="Pop"
    print(output)
genre()

def year_released():
    output=2020
    print(output)
year_released()

