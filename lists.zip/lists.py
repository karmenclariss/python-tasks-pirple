myUniqueList=[]
myLeftovers=[]

def add_list(number):
    if number not in myUniqueList:
        myUniqueList.append(number)
        return True
    else:
        add_leftovers(number)
        return False

def add_leftovers(number):
    myLeftovers.append(number)

#value that doesn't exist
print(add_list(3))
#value that exists
print(add_list(3))

print(myUniqueList)
print(myLeftovers)