#title
phrase: str="About the song"
print(phrase.upper())
# main details
song_title= "Wherever You Are"
genre= "Pop"
artist= "Kodaline"
duration=186
year_released=2020
month_released="January"
# secondary details
first_line="You say you love me"
last_line="That's where I'll be"


print(song_title)
print(artist)
print(str(duration) + "seconds")
print(genre)
print(year_released)
print(month_released)
print(first_line)
print(last_line)
