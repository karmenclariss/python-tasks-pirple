def isPrime(w):
    if w in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]:
        return True


for w in range(1, 101):
    output = ""
    if w % 3 == 0:
        output += "Fizz"
    if w % 5 == 0:
        output += "Buzz"
    elif isPrime(w):
        output = "Prime"
    print(output if len(output) else w)

